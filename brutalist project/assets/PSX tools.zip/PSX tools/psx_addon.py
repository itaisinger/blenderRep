import bpy
import bmesh
from bpy.types import Operator, Panel
try:
    from PIL import Image, ImageDraw
except ImportError:
    print("Pillow is not installed. Please install it using: pip install Pillow")
import os
import random
import numpy as np

import json
from pathlib import Path
bl_info = {
    "name": "PSX Retro Tools",
    "author": "Igor Shevchenko (https://x.com/cryptofawkek)",
    "version": (1, 0, 0),
    "blender": (4, 3, 0),
    "location": "View3D > Sidebar > PSX Retro",
    "description": "Tools for creating PSX-style retro graphics: low-poly simplifier, low-res texture baking, dithering, vertex wobble (including PRO screen-space wobble), render presets, and texture utilities.",
    "doc_url": "https://x.com/cryptofawkek",
    "category": "3D View"
}

# Глобальная переменная для хранения копии пикселей текстуры
_dither_backup = {}

def set_correct_uv_layer(obj):
    """Выбирает второй UV-слой, удаляет остальные или создаёт новый, если слоёв нет."""
    if obj.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')
    
    uv_layers = obj.data.uv_layers
    if len(uv_layers) > 1:
        target_uv = uv_layers[1].name
        uv_layers.active_index = 1
        uv_layers[1].active = True
        uv_layers[1].active_render = True
        to_delete = [uv.name for i, uv in enumerate(uv_layers) if i != 1]
        for name in to_delete:
            uv = uv_layers.get(name)
            if uv:
                uv_layers.remove(uv)
        print(f"[PSX] Kept UV layer: {target_uv}, deleted others.")
        return target_uv
    elif len(uv_layers) == 1:
        uv_layers[0].active = True
        uv_layers[0].active_render = True
        print(f"[PSX] Using single UV layer: {uv_layers[0].name}")
        return uv_layers[0].name
    else:
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.uv.smart_project(angle_limit=66.0, island_margin=0.02)
        bpy.ops.object.mode_set(mode='OBJECT')
        new_uv_name = uv_layers[0].name if uv_layers else "UVMap"
        print(f"[PSX] Created new UV layer: {new_uv_name}")
        return new_uv_name

def setup_material(obj, image, resolution):
    """Настройка материала для текстуры."""
    mat = obj.active_material
    if not mat:
        mat = bpy.data.materials.new(name=f"PSX_Material_{resolution}")
        mat.use_nodes = True
        obj.active_material = mat
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    for n in nodes:
        n.select = False
    tex_node = nodes.get('PSXBakeTex') or nodes.new('ShaderNodeTexImage')
    tex_node.name = 'PSXBakeTex'
    tex_node.image = image
    tex_node.interpolation = 'Closest'
    tex_node.extension = 'CLIP'
    tex_node.projection = 'FLAT'
    tex_node.select = True
    nodes.active = tex_node
    bsdf_node = next((n for n in nodes if n.type == 'BSDF_PRINCIPLED'), None)
    if not bsdf_node:
        bsdf_node = nodes.new('ShaderNodeBsdfPrincipled')
        links.new(bsdf_node.outputs['BSDF'], nodes['Material Output'].inputs['Surface'])
    for link in list(bsdf_node.inputs['Base Color'].links):
        links.remove(link)
    links.new(tex_node.outputs['Color'], bsdf_node.inputs['Base Color'])
    bsdf_node.inputs['Base Color'].default_value = (1.0, 0.0, 0.0, 1.0)
    
    uv_layer_name = set_correct_uv_layer(obj)
    uv_map_node = nodes.get('PSXUVMap') or nodes.new('ShaderNodeUVMap')
    uv_map_node.name = 'PSXUVMap'
    if uv_layer_name:
        uv_map_node.uv_map = uv_layer_name
        links.new(uv_map_node.outputs['UV'], tex_node.inputs['Vector'])
        print(f"[PSX] Assigned UV layer '{uv_layer_name}' to UV Map node in setup_material")
    
    return mat, tex_node

class LowPolyHelperOperator(Operator):
    bl_idname = "object.low_poly_helper"
    bl_label = "Low-Poly Helper"
    bl_description = "Simplify geometry by reducing polygons and triangulating, preserving all existing modifiers"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if not context.active_object or context.active_object.type != 'MESH':
            self.report({'ERROR'}, "Please select a mesh object!")
            return {'CANCELLED'}

        obj = context.active_object
        bpy.ops.object.mode_set(mode='OBJECT')

        decimate_ratio = context.scene.low_poly_ratio
        initial_tris = len([p for p in obj.data.polygons if len(p.vertices) == 3])
        self.report({'INFO'}, f"Initial triangles: {initial_tris}, Ratio: {decimate_ratio}")

        self.report({'INFO'}, f"Preserved {len(obj.modifiers)} existing modifiers")

        decimate_mod = obj.modifiers.new(name="PSX_Decimate", type='DECIMATE')
        decimate_mod.ratio = decimate_ratio
        bpy.context.view_layer.objects.active = obj
        bpy.context.view_layer.update()

        try:
            bpy.ops.object.modifier_apply(modifier=decimate_mod.name)
            self.report({'INFO'}, "Decimate modifier applied successfully.")
        except Exception as e:
            self.report({'ERROR'}, f"Failed to apply decimate modifier: {str(e)}")
            return {'CANCELLED'}

        post_decimate_tris = len([p for p in obj.data.polygons if len(p.vertices) == 3])
        self.report({'INFO'}, f"Triangles after decimate: {post_decimate_tris}")

        bpy.ops.object.mode_set(mode='EDIT')
        bm = bmesh.from_edit_mesh(obj.data)
        has_quads = any(len(p.verts) > 3 for p in bm.faces)
        if has_quads:
            self.report({'INFO'}, "Triangulating due to presence of quads.")
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.mesh.quads_convert_to_tris(quad_method='BEAUTY', ngon_method='BEAUTY')
            bmesh.update_edit_mesh(obj.data)
        bpy.ops.object.mode_set(mode='OBJECT')

        final_tris = len([p for p in obj.data.polygons if len(p.vertices) == 3])
        self.report({'INFO'}, f"Final triangles: {final_tris}")

        if final_tris > initial_tris:
            self.report({'WARNING'}, f"Triangulation increased triangles from {initial_tris} to {final_tris} due to quads.")
        self.report({'INFO'}, f"Simplified from {initial_tris} to {final_tris} triangles ({int(decimate_ratio * 100)}%)!")
        return {'FINISHED'}

class PSXTextureGeneratorOperator(Operator):
    bl_idname = "object.psx_texture_generator"
    bl_label = "Generate PSX Texture"
    bl_description = "Generate a low-resolution texture with limited color palette"
    bl_options = {'REGISTER', 'UNDO'}

    texture_size: bpy.props.EnumProperty(
        name="Texture Size",
        description="Resolution of the generated texture",
        items=[
            ('64', "64x64", "Low resolution texture"),
            ('128', "128x128", "Medium resolution texture"),
            ('256', "256x256", "High resolution texture"),
        ],
        default='64'
    )

    palette_size: bpy.props.IntProperty(
        name="Palette Size",
        description="Number of colors in the texture palette",
        min=8, max=256, default=16, step=1
    )

    texture_pattern: bpy.props.EnumProperty(
        name="Texture Pattern",
        description="Pattern for generated texture",
        items=[
            ('CHECKER', "Checkerboard", "Black and white checkerboard pattern"),
            ('GRADIENT', "Random Gradient", "Random gradient pattern"),
        ],
        default='CHECKER'
    )

    def invoke(self, context, event):
        self.texture_pattern = context.scene.psx_texture_pattern
        self.texture_size = context.scene.psx_texture_size
        self.palette_size = context.scene.psx_palette_size
        return self.execute(context)

    def execute(self, context):
        resolution = int(self.texture_size)
        palette_size = self.palette_size
        pattern = self.texture_pattern

        self.report({'INFO'}, f"Selected pattern: {pattern}")

        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "No mesh selected!")
            return {'CANCELLED'}

        image_name = f"PSX_Texture_{resolution}"
        image = bpy.data.images.get(image_name)
        if not image:
            image = bpy.data.images.new(name=image_name, width=resolution, height=resolution, alpha=True)
            image.generated_type = 'BLANK'
            image.generated_color = (1.0, 1.0, 1.0, 1.0)
        else:
            image.scale(resolution, resolution)
        image.use_fake_user = True

        mat, tex_node = setup_material(obj, image, resolution)

        temp_image = Image.new("RGBA", (resolution, resolution))
        draw = ImageDraw.Draw(temp_image)

        if pattern == 'CHECKER':
            cell_size = 8
            num_cells = resolution // cell_size
            for y in range(num_cells):
                for x in range(num_cells):
                    color = (255, 255, 255, 255) if (x + y) % 2 == 0 else (0, 0, 0, 255)
                    x0 = x * cell_size
                    y0 = y * cell_size
                    x1 = x0 + cell_size - 1
                    y1 = y0 + cell_size - 1
                    draw.rectangle([(x0, y0), (x1, y1)], fill=color)
            pattern_name = "checkerboard"
        elif pattern == 'GRADIENT':
            start_color = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255), 255)
            end_color = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255), 255)
            for y in range(resolution):
                for x in range(resolution):
                    t = (x + y) / (resolution * 2)
                    r = int(start_color[0] * (1 - t) + end_color[0] * t)
                    g = int(start_color[1] * (1 - t) + end_color[1] * t)
                    b = int(start_color[2] * (1 - t) + end_color[2] * t)
                    draw.point((x, y), fill=(r, g, b, 255))
            pattern_name = "random gradient"
        else:
            self.report({'ERROR'}, f"Unknown pattern: {pattern}")
            return {'CANCELLED'}

        try:
            temp_image = temp_image.convert("RGB").quantize(colors=palette_size, method=Image.MEDIANCUT)
            temp_image = temp_image.convert("RGBA")
        except Exception as e:
            self.report({'ERROR'}, f"Palette processing failed: {str(e)}")
            return {'CANCELLED'}

        rgb_pixels = [c / 255.0 for pixel in temp_image.getdata() for c in pixel]
        image.pixels = rgb_pixels
        image.pack()

        pixel_count = resolution * resolution
        pixels = [0.0] * (pixel_count * 4)
        image.pixels.foreach_get(pixels)
        self.report({'INFO'}, f"First pixel after pattern: {pixels[:4]}")

        obj['psx_tex_node'] = tex_node.name

        for area in bpy.context.screen.areas:
            if area.type == 'IMAGE_EDITOR':
                area.spaces.active.image = image
                break

        self.report({'INFO'}, f"PSX Texture ({resolution}x{resolution}, {palette_size} colors, {pattern_name}) generated!")
        return {'FINISHED'}

class PSXTextureBakeOperator(Operator):
    bl_idname = "object.psx_texture_bake"
    bl_label = "Bake Material Texture"
    bl_description = "Bake the material's base color or texture to a low-resolution texture"
    bl_options = {'REGISTER', 'UNDO'}

    texture_size: bpy.props.EnumProperty(
        name="Texture Size",
        description="Resolution of the baked texture",
        items=[
            ('64', "64x64", "Low resolution texture"),
            ('128', "128x128", "Medium resolution texture"),
            ('256', "256x256", "High resolution texture"),
        ],
        default='64'
    )

    palette_size: bpy.props.IntProperty(
        name="Palette Size",
        description="Number of colors in the texture palette",
        min=8, max=256, default=16, step=1
    )

    def invoke(self, context, event):
        self.texture_size = context.scene.psx_texture_size
        self.palette_size = context.scene.psx_palette_size
        return self.execute(context)

    def setup_bake_material(self, obj, image, resolution, existing_tex_node=None):
        """Настройка материала для запекания с Emission."""
        mat = obj.active_material
        if not mat or not mat.use_nodes:
            mat = bpy.data.materials.new(name=f"PSX_Bake_Mat_{image.name}")
            mat.use_nodes = True
            obj.active_material = mat
            self.report({'INFO'}, "Created new material for baking.")
        
        nodes = mat.node_tree.nodes
        links = mat.node_tree.links
        for n in nodes:
            n.select = False

        tex_node = existing_tex_node or nodes.get('PSXBakeTex') or nodes.new('ShaderNodeTexImage')
        tex_node.name = 'PSXBakeTex'
        tex_node.image = image
        tex_node.interpolation = 'Closest'
        tex_node.extension = 'CLIP'
        tex_node.projection = 'FLAT'
        tex_node.select = True
        nodes.active = tex_node

        uv_layer_name = set_correct_uv_layer(obj)
        uv_map_node = nodes.get('PSXUVMap') or nodes.new('ShaderNodeUVMap')
        uv_map_node.name = 'PSXUVMap'
        if uv_layer_name:
            uv_map_node.uv_map = uv_layer_name
            self.report({'INFO'}, f"Assigned UV layer '{uv_layer_name}' to UV Map node")
            links.new(uv_map_node.outputs['UV'], tex_node.inputs['Vector'])

        emission_node = nodes.get('PSX_Emission') or nodes.new('ShaderNodeEmission')
        emission_node.name = 'PSX_Emission'

        output_node = next((n for n in nodes if n.type == 'OUTPUT_MATERIAL'), None)
        if not output_node:
            output_node = nodes.new('ShaderNodeOutputMaterial')

        bsdf_node = next((n for n in nodes if n.type == 'BSDF_PRINCIPLED'), None)
        base_color = (1.0, 0.0, 0.0, 1.0) if not bsdf_node else bsdf_node.inputs['Base Color'].default_value
        self.report({'INFO'}, f"Using base color for emission: {base_color}")

        linked_color = None
        if bsdf_node and bsdf_node.inputs['Base Color'].is_linked:
            linked_color = bsdf_node.inputs['Base Color'].links[0].from_node
            self.report({'INFO'}, f"Found linked node: {linked_color.name}")
        elif existing_tex_node:
            linked_color = existing_tex_node
            self.report({'INFO'}, f"Using existing texture node: {existing_tex_node.name}")

        for link in list(output_node.inputs['Surface'].links):
            links.remove(link)
        for link in list(emission_node.inputs['Color'].links):
            links.remove(link)

        if linked_color and linked_color.type == 'TEX_IMAGE':
            links.new(linked_color.outputs['Color'], emission_node.inputs['Color'])
            self.report({'INFO'}, f"Using texture '{linked_color.name}' as emission source")
        else:
            emission_node.inputs['Color'].default_value = base_color
            self.report({'INFO'}, "Using solid color for emission")

        emission_node.inputs['Strength'].default_value = 1.0
        links.new(emission_node.outputs['Emission'], output_node.inputs['Surface'])

        return mat, emission_node, tex_node

    def bake_image(self, obj, image, bake_type='EMIT'):
        """Запекание текстуры с использованием Emission ноды."""
        wm = bpy.context.window_manager
        wm.progress_begin(0, 100)
        wm.progress_update(0)
        self.report({'INFO'}, "Starting texture bake...")

        bpy.context.view_layer.objects.active = obj
        obj.select_set(True)

        uv_layer_name = set_correct_uv_layer(obj)
        if not uv_layer_name:
            wm.progress_end()
            self.report({'ERROR'}, "Failed to set or create UV layer!")
            return False
        self.report({'INFO'}, f"Using UV layer '{uv_layer_name}' for baking.")

        scene = bpy.context.scene
        scene.render.engine = 'CYCLES'
        scene.cycles.device = 'CPU'
        scene.cycles.samples = 64
        scene.cycles.bake_type = bake_type
        scene.render.bake.use_pass_direct = False
        scene.render.bake.use_pass_indirect = False
        scene.render.bake.use_pass_color = True
        scene.cycles.bake_margin = 0

        wm.progress_update(50)
        image.update()
        try:
            bpy.ops.object.bake(type=bake_type)
            wm.progress_update(90)
            self.report({'INFO'}, "Bake completed successfully.")
            wm.progress_end()
            return True
        except Exception as e:
            wm.progress_end()
            self.report({'ERROR'}, f"Bake failed: {str(e)}")
            return False

    def process_bake_result(self, obj, image, resolution, palette_size):
        """Обработка результата запекания."""
        wm = bpy.context.window_manager
        wm.progress_begin(0, 100)
        wm.progress_update(0)
        self.report({'INFO'}, "Processing bake result...")

        pixel_count = resolution * resolution
        pixels = [0.0] * (pixel_count * 4)
        image.pixels.foreach_get(pixels)
        self.report({'INFO'}, f"First pixel after bake: {pixels[:4]}")

        if all(p == 0.0 for p in pixels) or all(p == 1.0 for p in pixels):
            wm.progress_end()
            self.report({'WARNING'}, "Bake result is empty or solid color! Check material and UV map.")
            return False

        try:
            pixel_data = [(int(pixels[i] * 255), int(pixels[i + 1] * 255), int(pixels[i + 2] * 255), int(pixels[i + 3] * 255))
                         for i in range(0, len(pixels), 4)]
            temp_image = Image.new("RGBA", (resolution, resolution))
            temp_image.putdata(pixel_data)
            self.report({'INFO'}, f"Sample pixel data: {pixel_data[:5]}")
            wm.progress_update(50)

            temp_image = temp_image.convert("RGB").quantize(colors=palette_size, method=Image.MEDIANCUT)
            temp_image = temp_image.convert("RGBA")
            wm.progress_update(75)

            debug_pixel = list(temp_image.getdata())[0]
            self.report({'INFO'}, f"Debug pixel (post-palette): {debug_pixel}")

            rgb_pixels = [c / 255.0 for pixel in temp_image.getdata() for c in pixel]
            image.pixels = rgb_pixels
            image.pack()
            wm.progress_update(90)

            pixels = [0.0] * (pixel_count * 4)
            image.pixels.foreach_get(pixels)
            self.report({'INFO'}, f"First pixel after processing: {pixels[:4]}")
            if all(p == 0.0 for p in pixels):
                wm.progress_end()
                self.report({'ERROR'}, "Texture is empty after processing!")
                return False
            wm.progress_end()
            self.report({'INFO'}, "Texture processed with limited palette successfully!")
            return True
        except Exception as e:
            wm.progress_end()
            self.report({'ERROR'}, f"Failed to process bake result: {str(e)}")
            return False

    def execute(self, context):
        wm = bpy.context.window_manager
        wm.progress_begin(0, 100)
        wm.progress_update(0)
        self.report({'INFO'}, "Starting PSX texture bake...")

        resolution = int(self.texture_size)
        palette_size = self.palette_size

        obj = context.active_object
        if not obj or obj.type != 'MESH':
            wm.progress_end()
            self.report({'ERROR'}, "No mesh selected!")
            return {'CANCELLED'}

        image_name = f"PSX_Bake_Texture_{resolution}"
        image = bpy.data.images.get(image_name)
        if not image:
            image = bpy.data.images.new(name=image_name, width=resolution, height=resolution, alpha=True)
            image.generated_type = 'BLANK'
            image.generated_color = (1.0, 1.0, 1.0, 1.0)
        else:
            image.scale(resolution, resolution)
        image.use_fake_user = True
        wm.progress_update(10)

        existing_tex_node = None
        if 'psx_tex_node' in obj:
            tex_node_name = obj['psx_tex_node']
            existing_tex_node = obj.active_material.node_tree.nodes.get(tex_node_name)

        mat, emission_node, tex_node = self.setup_bake_material(obj, image, resolution, existing_tex_node)
        wm.progress_update(20)

        if not self.bake_image(obj, image, bake_type='EMIT'):
            return {'CANCELLED'}

        if not self.process_bake_result(obj, image, resolution, palette_size):
            return {'CANCELLED'}

        mat.node_tree.nodes.remove(emission_node)
        wm.progress_update(95)

        setup_material(obj, image, resolution)
        mat = obj.active_material
        nodes = mat.node_tree.nodes
        links = mat.node_tree.links
        bsdf_node = next((n for n in nodes if n.type == 'BSDF_PRINCIPLED'), None)
        output_node = next((n for n in nodes if n.type == 'OUTPUT_MATERIAL'), None)
        if bsdf_node and output_node:
            for link in list(output_node.inputs['Surface'].links):
                links.remove(link)
            links.new(bsdf_node.outputs['BSDF'], output_node.inputs['Surface'])

        for area in bpy.context.screen.areas:
            if area.type == 'IMAGE_EDITOR':
                area.spaces.active.image = image
                break

        wm.progress_end()
        self.report({'INFO'}, f"PSX Texture ({resolution}x{resolution}, {palette_size} colors, baked material) generated!")

        def draw_popup(self, context):
            self.layout.label(text=f"Texture Bake Completed: {resolution}x{resolution}, {palette_size} colors")
        bpy.context.window_manager.popup_menu(draw_popup, title="Bake Complete", icon='INFO')

        return {'FINISHED'}

class PSXTextureDitherOperator(Operator):
    bl_idname = "object.psx_texture_dither"
    bl_label = "Apply Dithering Effect"
    bl_description = "Apply a color dithering effect to the active texture"
    bl_options = {'REGISTER', 'UNDO'}

    dither_method: bpy.props.EnumProperty(
        name="Dither Method",
        description="Dithering algorithm to apply",
        items=[
            ('BAYER', "Bayer 4x4 (fast)", "Ordered dithering with a 4x4 Bayer matrix, fast and retro-styled"),
            ('FLOYD_STEINBERG', "Floyd-Steinberg (slow)", "Classic error diffusion with 4 neighbors"),
            ('JJN', "Jarvis, Judice, Ninke (slow)", "Smoother dithering with 12 neighbors"),
            ('STUCKI', "Stucki (slow)", "Optimized version of JJN, slightly faster"),
            ('BURKES', "Burkes (slow)", "Simplified Stucki, faster but less clean"),
            ('SIERRA', "Sierra (slow)", "Faster variant of JJN"),
            ('SIERRA_TWO_ROW', "Sierra Two-Row (slow)", "Simplified Sierra, faster"),
            ('SIERRA_LITE', "Sierra Lite (slow)", "Minimalist Floyd-Steinberg derivative"),
            ('ATKINSON', "Atkinson (slow)", "Retro-style dithering with 75% error propagation"),
        ],
        default='BAYER'
    )

    palette_size: bpy.props.IntProperty(
        name="Palette Size",
        description="Number of colors in the dithered texture palette",
        min=2, max=256, default=16, step=1
    )

    dither_scale: bpy.props.FloatProperty(
        name="Dither Scale",
        description="Scale of the dithering effect (higher values make patterns coarser)",
        min=0.1, max=2.0, default=0.1, step=1
    )

    def invoke(self, context, event):
        self.dither_method = context.scene.psx_dither_method
        self.palette_size = context.scene.psx_dither_palette_size
        self.dither_scale = context.scene.psx_dither_scale
        return self.execute(context)

    def get_dither_matrix(self, method):
        """Возвращает матрицу дизеринга и делитель для выбранного метода."""
        if method == 'BAYER':
            return [
                [0/16, 8/16, 2/16, 10/16],
                [12/16, 4/16, 14/16, 6/16],
                [3/16, 11/16, 1/16, 9/16],
                [15/16, 7/16, 13/16, 5/16]
            ], 16
        elif method == 'FLOYD_STEINBERG':
            return [[0, 0, 7/16], [3/16, 5/16, 1/16]], 16
        elif method == 'JJN':
            return [[0, 0, 0, 7/48, 5/48], [3/48, 5/48, 7/48, 5/48, 3/48], [1/48, 3/48, 5/48, 3/48, 1/48]], 48
        elif method == 'STUCKI':
            return [[0, 0, 0, 8/42, 4/42], [2/42, 4/42, 8/42, 4/42, 2/42], [1/42, 2/42, 4/42, 2/42, 1/42]], 42
        elif method == 'BURKES':
            return [[0, 0, 0, 8/32, 4/32], [2/32, 4/32, 8/32, 4/32, 2/32]], 32
        elif method == 'SIERRA':
            return [[0, 0, 0, 5/32, 3/32], [2/32, 4/32, 5/32, 4/32, 2/32], [0, 2/32, 3/32, 2/32, 0]], 32
        elif method == 'SIERRA_TWO_ROW':
            return [[0, 0, 0, 4/16, 3/16], [1/16, 2/16, 3/16, 2/16, 1/16]], 16
        elif method == 'SIERRA_LITE':
            return [[0, 0, 2/4], [1/4, 1/4, 0]], 4
        elif method == 'ATKINSON':
            return [[0, 0, 1/8, 1/8], [1/8, 1/8, 1/8, 0], [0, 1/8, 0, 0]], 8
        return None, 0

    def apply_dithering(self, image, method, palette_size, dither_scale):
        """Применяет цветной дизеринг к изображению с поддержкой Bayer."""
        wm = bpy.context.window_manager
        wm.progress_begin(0, 100)
        wm.progress_update(0)
        self.report({'INFO'}, f"Starting dithering with method: {method}")

        # Получаем размеры изображения
        width, height = image.size[0], image.size[1]
        original_size = (width, height)
        max_size = 512

        # Cancel dithering for large images
        if max(width, height) > 1024:
            self.report({'WARNING'}, f"Dithering skipped: texture too large ({width}x{height} > 1024x1024)")
            return None
            width, height = width, height

        # Получаем пиксели и преобразуем в массив NumPy
        pixels = np.array(image.pixels[:]).reshape((height, width, 4))
        pixels[:, :, 3] = 1.0  # Устанавливаем альфа-канал в 1.0
        temp_image = Image.frombytes("RGBA", (width, height), (pixels * 255).astype(np.uint8))
        temp_image = temp_image.convert("RGB")

        # Уменьшаем изображение, если нужно
        if (width, height) != (width, height):
            temp_image = temp_image.resize((width, height), Image.Resampling.NEAREST)

        wm.progress_update(10)

        # Квантование палитры
        try:
            temp_image = temp_image.quantize(colors=palette_size, method=Image.MEDIANCUT, dither=Image.NONE)
            temp_image = temp_image.convert("RGB")
            self.report({'INFO'}, "Palette recalculated to include painted colors")
            wm.progress_update(20)
        except Exception as e:
            wm.progress_end()
            self.report({'ERROR'}, f"Failed to recalculate palette: {str(e)}")
            return None

        # Получаем матрицу дизеринга
        matrix, divisor = self.get_dither_matrix(method)
        if not matrix:
            wm.progress_end()
            self.report({'ERROR'}, f"Unknown dither method: {method}")
            return None

        # Применяем дизеринг
        pixel_data = np.array(temp_image).astype(float)
        height, width, _ = pixel_data.shape
        step = 255.0 / (palette_size - 1)

        if method == 'BAYER':
            # Bayer дизеринг (упорядоченный)
            matrix = np.array(matrix, dtype=np.float32)
            matrix_height, matrix_width = matrix.shape
            # Создаём повторяющуюся матрицу Bayer
            tiled_matrix = np.tile(matrix, (height // matrix_height + 1, width // matrix_width + 1))
            tiled_matrix = tiled_matrix[:height, :width] * 255.0 * dither_scale

            # Применяем дизеринг для каждого канала
            for channel in range(3):
                channel_data = pixel_data[:, :, channel]
                dithered = channel_data + tiled_matrix
                pixel_data[:, :, channel] = np.round(dithered / step) * step
                pixel_data[:, :, channel] = np.clip(pixel_data[:, :, channel], 0, 255)
                wm.progress_update(20 + ((channel + 1) / 3) * 70)
        else:
            # Error diffusion дизеринг
            total_steps = height * 3
            current_step = 0
            for channel in range(3):
                for y in range(height):
                    for x in range(width):
                        old_pixel = pixel_data[y, x, channel]
                        new_pixel = round(old_pixel / step) * step
                        new_pixel = min(max(new_pixel, 0), 255)
                        error = (old_pixel - new_pixel) * dither_scale
                        error = max(min(error, 255.0), -255.0)
                        pixel_data[y, x, channel] = new_pixel

                        for dy, row in enumerate(matrix):
                            for dx, weight in enumerate(row):
                                if weight == 0:
                                    continue
                                ny, nx = y + dy, x + dx - (len(row) // 2)
                                if 0 <= ny < height and 0 <= nx < width:
                                    pixel_data[ny, nx, channel] += error * weight
                    current_step += 1
                    wm.progress_update(20 + (current_step / total_steps) * 70)

        temp_image = Image.fromarray(pixel_data.astype(np.uint8), mode="RGB").convert("RGBA")
        # Возвращаем изображение в исходный размер
        if (width, height) != (width, height):
            temp_image = temp_image.resize((width, height), Image.Resampling.NEAREST)
            self.report({'INFO'}, f"Restored texture to original size: {width}x{height}")

        # Преобразуем обратно в Blender
        rgb_pixels = [c / 255.0 for pixel in temp_image.getdata() for c in pixel]
        image.pixels = rgb_pixels
        image.pack()
        wm.progress_update(95)
        self.report({'INFO'}, f"Sample pixel after dithering: {rgb_pixels[:4]}")
        wm.progress_end()

        def draw_popup(self, context):
            self.layout.label(text=f"Dithering Completed: {method}, {palette_size} colors, scale {dither_scale}")
        bpy.context.window_manager.popup_menu(draw_popup, title="Dithering Complete", icon='INFO')

        return image

    def execute(self, context):
        wm = bpy.context.window_manager
        wm.progress_begin(0, 100)
        wm.progress_update(0)
        self.report({'INFO'}, "Preparing to apply dithering...")

        obj = context.active_object
        if not obj or obj.type != 'MESH':
            wm.progress_end()
            self.report({'ERROR'}, "No mesh selected!")
            return {'CANCELLED'}

        mat = obj.active_material
        if not mat or not mat.use_nodes:
            wm.progress_end()
            self.report({'ERROR'}, "No material with nodes found!")
            return {'CANCELLED'}

        tex_node = None
        if 'psx_tex_node' in obj:
            tex_node_name = obj['psx_tex_node']
            tex_node = mat.node_tree.nodes.get(tex_node_name)
            if tex_node and tex_node.type == 'TEX_IMAGE' and tex_node.image:
                self.report({'INFO'}, f"Using texture from psx_tex_node: {tex_node.image.name}")
            else:
                tex_node = None

        # Prefer explicit PSX bake/display textures
        if not tex_node:
            cand = mat.node_tree.nodes.get('PSXBakeTex')
            if cand and cand.type == 'TEX_IMAGE' and cand.image:
                tex_node = cand

        if not tex_node:
            for node in mat.node_tree.nodes:
                if node.type == 'TEX_IMAGE' and node.image and (node.image.name.startswith('PSX_Bake_Texture_') or node.image.name.startswith('PSX_Texture_')):
                    tex_node = node
                    break

        # Fallback to first TEX_IMAGE in material
        if not tex_node:
            for node in mat.node_tree.nodes:
                if node.type == 'TEX_IMAGE' and node.image:
                    tex_node = node
                    self.report({'INFO'}, f"Fallback to first TEX_IMAGE node: {tex_node.image.name}")
                    break

        if not tex_node or not tex_node.image:
            wm.progress_end()
            self.report({'ERROR'}, "No valid texture found in the material!")
            return {'CANCELLED'}

        image = tex_node.image
        global _dither_backup
        pixel_count = image.size[0] * image.size[1]
        pixels = [0.0] * (pixel_count * 4)
        image.pixels.foreach_get(pixels)
        _dither_backup[image.name] = pixels.copy()
        self.report({'INFO'}, f"Backup created for texture: {image.name}")
        wm.progress_update(5)

        try:
            image = self.apply_dithering(image, self.dither_method, self.palette_size, self.dither_scale)
            if not image:
                return {'CANCELLED'}
            for area in bpy.context.screen.areas:
                if area.type == 'IMAGE_EDITOR':
                    area.spaces.active.image = image
                    break
            self.report({'INFO'}, f"Color dithering ({self.dither_method}, {self.palette_size} colors, scale {self.dither_scale}) applied to texture!")
            return {'FINISHED'}
        except Exception as e:
            wm.progress_end()
            self.report({'ERROR'}, f"Failed to apply dithering: {str(e)}")
            return {'CANCELLED'}

class PSXTextureUndoDitherOperator(Operator):
    bl_idname = "object.psx_texture_undo_dither"
    bl_label = "Undo Dithering"
    bl_description = "Restore the texture to its state before dithering"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "No mesh selected!")
            return {'CANCELLED'}

        mat = obj.active_material
        if not mat or not mat.use_nodes:
            self.report({'ERROR'}, "No material with nodes found!")
            return {'CANCELLED'}

        tex_node = None
        if 'psx_tex_node' in obj:
            tex_node_name = obj['psx_tex_node']
            tex_node = mat.node_tree.nodes.get(tex_node_name)
            if tex_node and tex_node.type == 'TEX_IMAGE' and tex_node.image:
                self.report({'INFO'}, f"Using texture from psx_tex_node: {tex_node.image.name}")
            else:
                tex_node = None

        if not tex_node:
            for node in mat.node_tree.nodes:
                if node.type == 'TEX_IMAGE' and node.image:
                    tex_node = node
                    self.report({'INFO'}, f"Fallback to first TEX_IMAGE node: {tex_node.image.name}")
                    break

        if not tex_node or not tex_node.image:
            self.report({'ERROR'}, "No valid texture found in the material!")
            return {'CANCELLED'}

        image = tex_node.image
        global _dither_backup
        if image.name not in _dither_backup:
            self.report({'ERROR'}, f"No backup found for texture: {image.name}")
            return {'CANCELLED'}

        try:
            image.pixels = _dither_backup[image.name]
            image.pack()
            for area in bpy.context.screen.areas:
                if area.type == 'IMAGE_EDITOR':
                    area.spaces.active.image = image
                    break
            self.report({'INFO'}, f"Restored texture: {image.name}")
            def draw_popup(self, context):
                self.layout.label(text=f"Dithering undone for texture: {image.name}")
            bpy.context.window_manager.popup_menu(draw_popup, title="Undo Dithering Complete", icon='INFO')
            del _dither_backup[image.name]
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to undo dithering: {str(e)}")
            return {'CANCELLED'}

class PSXVertexWobbleOperator(Operator):
    bl_idname = "object.psx_vertex_wobble"
    bl_label = "Apply Vertex Wobble"
    bl_description = "Apply a PSX-style vertex wobble effect using Geometry Nodes"
    bl_options = {'REGISTER', 'UNDO'}

    wobble_amplitude: bpy.props.FloatProperty(
        name="Wobble Amplitude",
        description="Amplitude of vertex wobble (in Blender units)",
        min=0.0, max=0.2, default=0.07, step=1, precision=3
    )
    wobble_frequency: bpy.props.FloatProperty(
        name="Wobble Frequency",
        description="Frequency of wobble (controls speed of jitter)",
        min=0.1, max=10.0, default=6.2, step=1, precision=2
    )
    wobble_axes: bpy.props.EnumProperty(
        name="Wobble Axes",
        description="Axes along which to apply the wobble effect",
        items=[
            ('Z', "Z Only", "Apply wobble only along the Z axis"),
            ('XYZ', "All Axes", "Apply wobble along X, Y, and Z axes"),
        ],
        default='Z'
    )

    def invoke(self, context, event):
        self.wobble_amplitude = context.scene.psx_wobble_amplitude
        self.wobble_frequency = context.scene.psx_wobble_frequency
        self.wobble_axes = context.scene.psx_wobble_axes
        return self.execute(context)

    def execute(self, context):
        wm = bpy.context.window_manager
        wm.progress_begin(0, 100)
        wm.progress_update(0)
        self.report({'INFO'}, "Starting vertex wobble setup...")

        obj = context.active_object
        if not obj or obj.type != 'MESH':
            wm.progress_end()
            self.report({'ERROR'}, "Select a mesh object.")
            return {'CANCELLED'}

        # Создаём модификатор Geometry Nodes
        mod = obj.modifiers.new(name="PSX_Wobble", type='NODES')
        if not mod:
            wm.progress_end()
            self.report({'ERROR'}, "Failed to create Geometry Nodes modifier!")
            return {'CANCELLED'}

        # Создаём группу нод
        node_group = bpy.data.node_groups.new(name="PSX_Wobble_Group", type='GeometryNodeTree')
        mod.node_group = node_group
        nodes = node_group.nodes
        links = node_group.links
        nodes.clear()
        wm.progress_update(20)

        # Создаём интерфейсные сокеты
        try:
            node_group.interface.new_socket(
                name="Geometry",
                description="Geometry input",
                in_out='INPUT',
                socket_type='NodeSocketGeometry'
            )
            node_group.interface.new_socket(
                name="Geometry",
                description="Geometry output",
                in_out='OUTPUT',
                socket_type='NodeSocketGeometry'
            )
        except Exception as e:
            wm.progress_end()
            self.report({'ERROR'}, f"Failed to create interface sockets: {str(e)}")
            return {'CANCELLED'}

        # Создаём ноды
        input_node = nodes.new("NodeGroupInput")
        input_node.name = 'PSX_Wobble_Input'
        input_node.location = (-1000, 0)

        output_node = nodes.new("NodeGroupOutput")
        output_node.name = 'PSX_Wobble_Output'
        output_node.location = (1200, 0)

        # Scene Time (Frame)
        scene_time = nodes.new("GeometryNodeInputSceneTime")
        scene_time.name = 'PSX_Wobble_Frame'
        scene_time.location = (-1000, -400)

        # Position
        position_node = nodes.new("GeometryNodeInputPosition")
        position_node.name = 'PSX_Wobble_Position'
        position_node.location = (-1000, 0)

        # Separate XYZ
        separate_xyz = nodes.new("ShaderNodeSeparateXYZ")
        separate_xyz.name = 'PSX_Wobble_SeparateXYZ'
        separate_xyz.location = (-800, 0)
        links.new(position_node.outputs['Position'], separate_xyz.inputs['Vector'])

        # Combine X, Y, Z for seed
        combine_seed = nodes.new("ShaderNodeCombineXYZ")
        combine_seed.name = 'PSX_Wobble_CombineSeed'
        combine_seed.location = (-600, 0)
        links.new(separate_xyz.outputs['X'], combine_seed.inputs[0])
        links.new(separate_xyz.outputs['Y'], combine_seed.inputs[1])
        links.new(separate_xyz.outputs['Z'], combine_seed.inputs[2])

        # Frame * Frequency
        frame_mult = nodes.new("ShaderNodeMath")
        frame_mult.name = 'PSX_Wobble_FrameMult'
        frame_mult.operation = 'MULTIPLY'
        frame_mult.inputs[1].default_value = self.wobble_frequency
        frame_mult.location = (-800, -400)
        links.new(scene_time.outputs['Frame'], frame_mult.inputs[0])

        # Seed + Frame * Frequency
        seed_plus_frame = nodes.new("ShaderNodeVectorMath")
        seed_plus_frame.name = 'PSX_Wobble_SeedPlusFrame'
        seed_plus_frame.operation = 'ADD'
        seed_plus_frame.location = (-400, 0)
        links.new(combine_seed.outputs['Vector'], seed_plus_frame.inputs[0])
        links.new(frame_mult.outputs['Value'], seed_plus_frame.inputs[1])

        # Sine
        sine_node = nodes.new("ShaderNodeVectorMath")
        sine_node.name = 'PSX_Wobble_Sine'
        sine_node.operation = 'SINE'
        sine_node.location = (-200, 0)
        links.new(seed_plus_frame.outputs['Vector'], sine_node.inputs[0])

        # Modulo (to create sharp jumps)
        modulo_node = nodes.new("ShaderNodeVectorMath")
        modulo_node.name = 'PSX_Wobble_Modulo'
        modulo_node.operation = 'MODULO'
        modulo_node.inputs[1].default_value = (0.3, 0.3, 0.3)
        modulo_node.location = (0, 0)
        links.new(sine_node.outputs['Vector'], modulo_node.inputs[0])

        # Normalize (subtract mean to prevent floating)
        normalize_node = nodes.new("ShaderNodeVectorMath")
        normalize_node.name = 'PSX_Wobble_Normalize'
        normalize_node.operation = 'SUBTRACT'
        normalize_node.inputs[1].default_value = (0.15, 0.15, 0.15)  # Mean of modulo 0.3 is ~0.15
        normalize_node.location = (200, 0)
        links.new(modulo_node.outputs['Vector'], normalize_node.inputs[0])

        # Multiply by amplitude
        amp_mult = nodes.new("ShaderNodeVectorMath")
        amp_mult.name = 'PSX_Wobble_AmpMult'
        amp_mult.operation = 'MULTIPLY'
        amp_mult.inputs[1].default_value = (self.wobble_amplitude, self.wobble_amplitude, self.wobble_amplitude)
        amp_mult.location = (400, 0)
        links.new(normalize_node.outputs['Vector'], amp_mult.inputs[0])

        # Combine XYZ for offset
        combine = nodes.new("ShaderNodeCombineXYZ")
        combine.name = 'PSX_Wobble_Combine'
        combine.location = (600, 0)
        if self.wobble_axes == 'Z':
            links.new(amp_mult.outputs['Vector'], combine.inputs[2])  # Only Z
            combine.inputs[0].default_value = 0.0
            combine.inputs[1].default_value = 0.0
        else:
            links.new(amp_mult.outputs['Vector'], combine.inputs[0])  # X
            links.new(amp_mult.outputs['Vector'], combine.inputs[1])  # Y
            links.new(amp_mult.outputs['Vector'], combine.inputs[2])  # Z

        # Vector Math: Add Position + Offset
        add_offset = nodes.new("ShaderNodeVectorMath")
        add_offset.name = 'PSX_Wobble_AddOffset'
        add_offset.operation = 'ADD'
        add_offset.location = (800, 0)
        links.new(position_node.outputs['Position'], add_offset.inputs[0])
        links.new(combine.outputs['Vector'], add_offset.inputs[1])

        # Set Position
        set_pos = nodes.new("GeometryNodeSetPosition")
        set_pos.name = 'PSX_Wobble_SetPosition'
        set_pos.location = (1000, 0)
        links.new(input_node.outputs['Geometry'], set_pos.inputs['Geometry'])
        links.new(add_offset.outputs['Vector'], set_pos.inputs['Position'])

        # Соединение с выходом
        links.new(set_pos.outputs['Geometry'], output_node.inputs['Geometry'])

        wm.progress_update(90)
        self.report({'INFO'}, f"Vertex wobble applied (amplitude: {self.wobble_amplitude}, frequency: {self.wobble_frequency}, axes: {self.wobble_axes})")
        wm.progress_end()

        # Передаём параметры для popup
        amp = self.wobble_amplitude
        freq = self.wobble_frequency
        axes = self.wobble_axes
        def draw_popup(menu, context):
            menu.layout.label(text=f"Vertex Wobble Applied: Amplitude {amp:.3f}, Frequency {freq:.2f}, Axes {axes}")
        bpy.context.window_manager.popup_menu(draw_popup, title="Wobble Complete", icon='INFO')

        return {'FINISHED'}

class PSXVertexWobbleRemoveOperator(Operator):
    bl_idname = "object.psx_vertex_wobble_remove"
    bl_label = "Remove Vertex Wobble"
    bl_description = "Remove the PSX vertex wobble effect from the object"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        wm = bpy.context.window_manager
        wm.progress_begin(0, 100)
        wm.progress_update(0)
        self.report({'INFO'}, "Removing vertex wobble...")

        obj = context.active_object
        if not obj or obj.type != 'MESH':
            wm.progress_end()
            self.report({'ERROR'}, "No mesh selected!")
            return {'CANCELLED'}

        # Удаляем модификатор PSX_Wobble
        mod = obj.modifiers.get('PSX_Wobble')
        if not mod:
            wm.progress_end()
            self.report({'WARNING'}, "No PSX Wobble modifier found!")
            return {'FINISHED'}

        node_group = mod.node_group
        obj.modifiers.remove(mod)
        if node_group:
            bpy.data.node_groups.remove(node_group)
        self.report({'INFO'}, "Removed PSX Wobble modifier")

        wm.progress_update(90)
        self.report({'INFO'}, "Vertex wobble removed")
        wm.progress_end()

        def draw_popup(self, context):
            self.layout.label(text="Vertex Wobble Removed")
        bpy.context.window_manager.popup_menu(draw_popup, title="Wobble Removal Complete", icon='INFO')

        return {'FINISHED'}


# ------------------------------------------------------------------------
# Operator: Fix Textures
# ------------------------------------------------------------------------

class PSX_OT_FixTextures(bpy.types.Operator):
    bl_idname = "psx.fix_textures"
    bl_label = "Fix Textures"
    bl_description = "Set all image textures to Closest interpolation (skips HDRI/environment maps)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # Collect environment images from World to skip
        env_images = set()
        try:
            w = context.scene.world
            if w and w.use_nodes and w.node_tree:
                for node in w.node_tree.nodes:
                    # Skip HDRI / Environment textures
                    if node.type == 'TEX_ENVIRONMENT' and getattr(node, 'image', None):
                        env_images.add(node.image)
        except Exception:
            pass

        changed_images = 0
        for img in bpy.data.images:
            if not img:
                continue
            # Skip internal buffers
            if getattr(img, "type", "") in {'RENDER_RESULT', 'COMPOSITING'}:
                continue
            # Skip HDRI images
            if img in env_images:
                continue
            try:
                if hasattr(img, "interpolation") and img.interpolation != 'Closest':
                    img.interpolation = 'Closest'
                    changed_images += 1
            except Exception:
                pass

        # Second pass: iterate all materials and set interpolation on all Image Texture nodes
        changed_nodes = 0
        for mat in bpy.data.materials:
            try:
                if not mat or not getattr(mat, "use_nodes", False) or not mat.node_tree:
                    continue
                for node in mat.node_tree.nodes:
                    if node.type == 'TEX_IMAGE':
                        # Skip if node's image is an environment image
                        if getattr(node, "image", None) in env_images:
                            continue
                        try:
                            if getattr(node, "interpolation", None) and node.interpolation != 'Closest':
                                node.interpolation = 'Closest'
                                changed_nodes += 1
                        except Exception:
                            pass
            except Exception:
                pass

        # Third pass: also update Image Texture nodes inside reusable Shader node groups
        for ng in bpy.data.node_groups:
            try:
                if getattr(ng, "bl_idname", "") != 'ShaderNodeTree':
                    continue
                for node in ng.nodes:
                    if node.type == 'TEX_IMAGE':
                        if getattr(node, "image", None) in env_images:
                            continue
                        try:
                            if getattr(node, "interpolation", None) and node.interpolation != 'Closest':
                                node.interpolation = 'Closest'
                                changed_nodes += 1
                        except Exception:
                            pass
            except Exception:
                pass

        self.report({'INFO'}, f"Textures fixed: {changed_images} images, {changed_nodes} nodes set to Closest (HDRI skipped)")
        return {'FINISHED'}


class PSXRenderSettingsOperator(Operator):
    bl_idname = "object.psx_render_settings"
    bl_label = "Apply PSX Render Settings"
    bl_description = "Apply PSX-style render settings with low resolution, no antialiasing, and limited color depth"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        wm = bpy.context.window_manager
        wm.progress_begin(0, 100)
        wm.progress_update(0)
        self.report({'INFO'}, "Applying PSX render settings...")

        scene = context.scene
        render = scene.render

        # Set resolution
        resolution = scene.psx_render_resolution
        res_x, res_y = map(int, resolution.split('x'))
        render.resolution_x = res_x
        render.resolution_y = res_y
        self.report({'INFO'}, f"Set resolution to {res_x}x{res_y}")
        wm.progress_update(20)

        # Disable antialiasing depending on the engine
        if render.engine == 'BLENDER_EEVEE':
            scene.eevee.use_taa_reprojection = False
            self.report({'INFO'}, "Disabled TAA (temporal anti-aliasing) for EEVEE")
        elif render.engine == 'CYCLES':
            scene.cycles.use_adaptive_sampling = False
            self.report({'INFO'}, "Disabled adaptive sampling for Cycles")
        else:
            self.report({'WARNING'}, f"No AA setting handled for engine: {render.engine}")
        wm.progress_update(40)

                # Set filter size for pixelated effect
        if scene.psx_use_low_filter_size:
            if render.engine in ('BLENDER_EEVEE', 'BLENDER_EEVEE_NEXT'):
                try:
                    scene.render.filter_size = 0.01
                    self.report({'INFO'}, f"Set Film Filter Size to 0.01 for {render.engine}")
                except Exception as e:
                    self.report({'WARNING'}, f"Could not set filter size on {render.engine}: {e}")
            elif render.engine == 'CYCLES':
                scene.cycles.filter_width = 0.01
                self.report({'INFO'}, "Set Filter Width to 0.01 for Cycles")
            else:
                self.report({'WARNING'}, f"No filter size setting handled for engine: {render.engine}")
        else:
            if render.engine in ('BLENDER_EEVEE', 'BLENDER_EEVEE_NEXT'):
                try:
                    scene.render.filter_size = 1.5  # Default for Eevee/Eevee Next
                    self.report({'INFO'}, f"Restored default Film Filter Size (1.5) for {render.engine}")
                except Exception as e:
                    self.report({'WARNING'}, f"Could not restore filter size on {render.engine}: {e}")
            elif render.engine == 'CYCLES':
                scene.cycles.filter_width = 2.0  # Default for Cycles
                self.report({'INFO'}, "Restored default Filter Width (2.0) for Cycles")
            else:
                self.report({'WARNING'}, f"No default filter size restored for engine: {render.engine}")
        wm.progress_update(50)

        # Shadows handling
        lowres_shadows = scene.psx_lowres_shadows
        disable_all_shadows = scene.psx_disable_all_shadows
        if disable_all_shadows:
            for obj in scene.objects:
                if obj.type == 'LIGHT':
                    try:
                        obj.data.use_shadow = False
                    except Exception:
                        pass
            self.report({'INFO'}, "All shadows disabled for all light sources")
        elif lowres_shadows:
            for obj in scene.objects:
                if obj.type == 'LIGHT':
                    L = obj.data
                    try:
                        L.use_shadow = True
                    except Exception:
                        pass
                    # Try low-res shadow map settings commonly available
                    for attr, val in [('shadow_buffer_size', 128), ('shadow_soft_size', 0.01)]:
                        if hasattr(L, attr):
                            try:
                                setattr(L, attr, val)
                            except Exception:
                                pass
                    # Some builds expose filter type
                    if hasattr(L, 'shadow_filter_type'):
                        try:
                            L.shadow_filter_type = 'BOX'
                        except Exception:
                            pass
                    # EEVEE/Next scene-level shadow sizes (best-effort)
                    try:
                        if hasattr(scene.eevee, 'shadow_cube_size'):
                            scene.eevee.shadow_cube_size = '128'
                        if hasattr(scene.eevee, 'shadow_cascade_size'):
                            scene.eevee.shadow_cascade_size = '128'
                    except Exception:
                        pass
            self.report({'INFO'}, "Applied low-resolution PSX-style shadows")
        else:
            self.report({'INFO'}, "Shadows unchanged (no low-res / disable-all selected)")
        wm.progress_update(60)

        # Disable denoising
        disable_denoising = scene.psx_disable_denoising
        if disable_denoising:
            if render.engine == 'BLENDER_EEVEE':
                scene.eevee.use_taa_reprojection = False
                self.report({'INFO'}, "Disabled denoising (TAA) for EEVEE")
            elif render.engine == 'CYCLES':
                scene.cycles.use_denoising = False
                self.report({'INFO'}, "Disabled denoising for Cycles")
            else:
                self.report({'WARNING'}, f"No denoising setting handled for engine: {render.engine}")
        wm.progress_update(80)

        # Set up color depth limitation via Compositor
        color_depth = scene.psx_color_depth
        scene.use_nodes = True
        nodes = scene.node_tree.nodes
        links = scene.node_tree.links
        for n in list(nodes):
            nodes.remove(n)
        render_node = nodes.new('CompositorNodeRLayers')
        render_node.location = (0, 0)
        output_node = nodes.new('CompositorNodeComposite')
        output_node.location = (400, 0)
        if color_depth == 'NONE':
            # Pass-through: no quantization
            links.new(render_node.outputs['Image'], output_node.inputs['Image'])
            self.report({'INFO'}, 'Color depth processing skipped (None)')
            color_depth_label = 'None'
        else:
            bits_per_channel = {'16BIT': 16, '8BIT': 8, '5BIT': 5}[color_depth]
            colors = 2 ** bits_per_channel
            quantize_node = nodes.new('CompositorNodePosterize')
            quantize_node.name = 'PSX_ColorDepth'
            quantize_node.inputs['Steps'].default_value = colors
            quantize_node.location = (200, 0)
            links.new(render_node.outputs['Image'], quantize_node.inputs['Image'])
            links.new(quantize_node.outputs['Image'], output_node.inputs['Image'])
            self.report({'INFO'}, f'Set color depth to {bits_per_channel}-bit ({colors} colors)')
            color_depth_label = f'{bits_per_channel}-bit'
        wm.progress_update(90)


        wm.progress_end()
        self.report({'INFO'}, f"PSX Render Settings applied: {res_x}x{res_y}, {'all shadows disabled' if scene.psx_disable_all_shadows else ('low-res shadows' if scene.psx_lowres_shadows else 'shadows unchanged')}, {'no denoising' if disable_denoising else 'denoising enabled'}, {color_depth_label} color depth, {'low filter size' if scene.psx_use_low_filter_size else 'default filter size'}")
        
        def draw_popup(self, context):
            self.layout.label(text=f"Render Settings Applied: {res_x}x{res_y}, {'all shadows disabled' if scene.psx_disable_all_shadows else ('low-res shadows' if scene.psx_lowres_shadows else 'shadows unchanged')}, {color_depth_label} color, {'low filter size' if scene.psx_use_low_filter_size else 'default filter size'}")
        bpy.context.window_manager.popup_menu(draw_popup, title="Render Settings Complete", icon='INFO')

        return {'FINISHED'}


# ------------------------------------------------------------------------
# Tools Panel
# ------------------------------------------------------------------------
class PSX_PT_Tools(bpy.types.Panel):
    bl_label = "Tools"
    bl_idname = "PSX_PT_tools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "PSX Retro"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        layout.operator("psx.fix_textures", icon='IMAGE_DATA')
        layout.label(text="Set all textures to Closest interpolation")


class PSXRetroPanel(Panel):
    bl_label = "PSX Retro Tools"
    bl_idname = "PT_PSXRetroPanel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'PSX Retro'

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        # Low-Poly Helper (foldout)
        box = layout.box()
        row = box.row(align=True)
        row.prop(scene, "psx_ui_lowpoly", text="", emboss=False,
                 icon='TRIA_DOWN' if scene.psx_ui_lowpoly else 'TRIA_RIGHT')
        row.label(text="Low-Poly Helper")
        if scene.psx_ui_lowpoly:
            box.prop(scene, "low_poly_ratio", text="Decimate Ratio", slider=True)
            box.operator("object.low_poly_helper", text="Apply Low-Poly")
            box.label(text="Use Ctrl+Z to undo if needed")

        # PSX Texture Generator (foldout)
        box = layout.box()
        row = box.row(align=True)
        row.prop(scene, "psx_ui_texgen", text="", emboss=False,
                 icon='TRIA_DOWN' if scene.psx_ui_texgen else 'TRIA_RIGHT')
        row.label(text="PSX Texture Generator")
        if scene.psx_ui_texgen:
            box.prop(scene, "psx_texture_size", text="Texture Size")
            box.prop(scene, "psx_palette_size", text="Palette Size", slider=True)
            box.prop(scene, "psx_texture_pattern", text="Texture Pattern")
            box.operator("object.psx_texture_generator", text="Generate Texture")
            box.label(text="Do not bake, it is already ready for use.")
            box.label(text="You can use Texture Paint to edit the generated texture")
            box.operator("object.psx_texture_bake", text="Bake Material Texture")
            box.label(text="Use for single object texture")
            box.label(text="Use Texture Paint to edit or Ctrl+Z to undo")
            box.prop(scene, "psx_dither_palette_size", text="Dither Palette Size", slider=True)
            box.prop(scene, "psx_dither_scale", text="Dither Scale", slider=True)
            box.prop(scene, "psx_dither_method", text="Dither Method")
            box.label(text="Do not use dithering on textures larger than 512x512 or with a palette size greater than 64, as it may be slow.")
            box.operator("object.psx_texture_dither", text="Apply Dithering")
            box.label(text="Apply dithering to the active texture")
            box.label(text="Dithering cannot be undone with Ctrl+Z, use Undo Dithering button")
            box.operator("object.psx_texture_undo_dither", text="Undo Dithering")

        # Vertex Wobble Effect (foldout)
        box = layout.box()
        row = box.row(align=True)
        row.prop(scene, "psx_ui_wobble", text="", emboss=False,
                 icon='TRIA_DOWN' if scene.psx_ui_wobble else 'TRIA_RIGHT')
        row.label(text="Vertex Wobble Effect")
        if scene.psx_ui_wobble:
            box.prop(scene, "psx_wobble_amplitude", text="Wobble Amplitude", slider=True)
            box.prop(scene, "psx_wobble_frequency", text="Wobble Frequency", slider=True)
            box.prop(scene, "psx_wobble_axes", text="Wobble Axes")
            box.operator("object.psx_vertex_wobble", text="Apply Vertex Wobble")
            box.operator("object.psx_vertex_wobble_remove", text="Remove Vertex Wobble")
            box.label(text="Applies a PSX-style vertex wobble effect using Geometry Nodes")

        # Vertex Wobble Pro (foldout)
        box = layout.box()
        row = box.row(align=True)
        row.prop(scene, "psx_ui_wobble_pro", text="", emboss=False,
                 icon='TRIA_DOWN' if scene.psx_ui_wobble_pro else 'TRIA_RIGHT')
        row.label(text="Vertex Wobble PRO")
        if scene.psx_ui_wobble_pro:
            col = box.column(align=True)
            col.prop(scene, "psxpro_freq", text="Frequency")
            col.prop(scene, "psxpro_hold", text="Hold Frames")
            col.prop(scene, "psxpro_seed", text="Seed")
            col.separator()
            col.prop(scene, "psxpro_axes", text="Axes")
            col.prop(scene, "psxpro_gamp", text="Global Amp")
            row2 = col.row(align=True)
            row2.prop(scene, "psxpro_ampx", text="Amp X")
            row2.prop(scene, "psxpro_ampy", text="Amp Y")
            row2.prop(scene, "psxpro_ampz", text="Amp Z")
            row3 = box.row(align=True)
            row3.operator("psx_wobble_pro.add", text="Add / Update", icon='MOD_NOISE')
            row3.operator("psx_wobble_pro.remove", text="Remove", icon='X')
            pbox = box.box()
            pbox.label(text="Presets")
            rowp = pbox.row(align=True)
            rowp.prop(scene, "psxpro_preset", text="Name")
            rowp.operator("psx_wobble_pro.apply_preset", text="", icon='CHECKMARK')
            pbox.operator("psx_wobble_pro.save_preset", text="Save As…", icon='EXPORT')

        # PSX Render Settings (foldout)
        box = layout.box()
        row = box.row(align=True)
        row.prop(scene, "psx_ui_render", text="", emboss=False,
                 icon='TRIA_DOWN' if scene.psx_ui_render else 'TRIA_RIGHT')
        row.label(text="PSX Render Settings")
        if scene.psx_ui_render:
            box.prop(scene, "psx_render_resolution", text="Resolution")
            box.prop(scene, "psx_lowres_shadows", text="Low Resolution Shadows")
            box.prop(scene, "psx_disable_all_shadows", text="Disable all shadows")
            box.prop(scene, "psx_disable_denoising", text="Disable Denoising")
            box.prop(scene, "psx_use_low_filter_size", text="Low Filter Size")
            box.prop(scene, "psx_color_depth", text="Color Depth")
            box.operator("object.psx_render_settings", text="Apply Render Settings")
            box.label(text="Applies PSX-style render settings with low resolution and limited color depth")

# ===== PSX Vertex Wobble PRO (integrated) =====
GN_NAME = 'PSX_Wobble_Pro_NG'
MOD_NAME = 'PSX_Wobble_Pro'
# ----------------------- GN group (PSX zero-mean pipeline) -----------------------
def ensure_gn_group():
    ng = bpy.data.node_groups.get(GN_NAME)
    if ng:
        return ng
    ng = bpy.data.node_groups.new(GN_NAME, 'GeometryNodeTree')
    nodes = ng.nodes; links = ng.links
    nodes.clear()
    # interface
    ng.interface.new_socket(name="Geometry", in_out='INPUT', socket_type='NodeSocketGeometry')
    ng.interface.new_socket(name="Geometry", in_out='OUTPUT', socket_type='NodeSocketGeometry')
    s_freq = ng.interface.new_socket(name="Frequency", in_out='INPUT', socket_type='NodeSocketFloat'); s_freq.default_value = 6.2
    s_gamp = ng.interface.new_socket(name="Amplitude Global", in_out='INPUT', socket_type='NodeSocketFloat'); s_gamp.default_value = 0.07
    s_ax = ng.interface.new_socket(name="Amp X", in_out='INPUT', socket_type='NodeSocketFloat'); s_ax.default_value = 0.0
    s_ay = ng.interface.new_socket(name="Amp Y", in_out='INPUT', socket_type='NodeSocketFloat'); s_ay.default_value = 0.0
    s_az = ng.interface.new_socket(name="Amp Z", in_out='INPUT', socket_type='NodeSocketFloat'); s_az.default_value = 0.07
    s_axes = ng.interface.new_socket(name="Axes Mode (0=Z,1=XYZ,2=Custom)", in_out='INPUT', socket_type='NodeSocketFloat'); s_axes.default_value = 0.0
    s_hold = ng.interface.new_socket(name="Hold Frames", in_out='INPUT', socket_type='NodeSocketFloat'); s_hold.default_value = 0.0
    s_seed = ng.interface.new_socket(name="Seed", in_out='INPUT', socket_type='NodeSocketFloat'); s_seed.default_value = 1.0

    # nodes
    n_in  = nodes.new("NodeGroupInput");  n_in.location  = (-1200, 0)
    n_out = nodes.new("NodeGroupOutput"); n_out.location = (1600, 0)

    n_pos = nodes.new("GeometryNodeInputPosition"); n_pos.location = (-1000, 200)
    n_sep = nodes.new("ShaderNodeSeparateXYZ"); n_sep.location = (-820, 200)
    links.new(n_pos.outputs['Position'], n_sep.inputs['Vector'])

    n_time = nodes.new("GeometryNodeInputSceneTime"); n_time.location = (-1000, -140)

    # hold frames (safe)
    n_max = nodes.new("ShaderNodeMath"); n_max.operation='MAXIMUM'; n_max.inputs[1].default_value = 1.0; n_max.location=(-840,-140)
    links.new(n_in.outputs['Hold Frames'], n_max.inputs[0])
    n_div = nodes.new("ShaderNodeMath"); n_div.operation='DIVIDE'; n_div.location=(-700,-140)
    links.new(n_time.outputs['Frame'], n_div.inputs[0]); links.new(n_max.outputs['Value'], n_div.inputs[1])
    n_floor = nodes.new("ShaderNodeMath"); n_floor.operation='FLOOR'; n_floor.location=(-560,-140); links.new(n_div.outputs['Value'], n_floor.inputs[0])
    n_mulh = nodes.new("ShaderNodeMath"); n_mulh.operation='MULTIPLY'; n_mulh.location=(-420,-140)
    links.new(n_floor.outputs['Value'], n_mulh.inputs[0]); links.new(n_max.outputs['Value'], n_mulh.inputs[1])
    n_gt0 = nodes.new("ShaderNodeMath"); n_gt0.operation='GREATER_THAN'; n_gt0.location=(-700,-220); links.new(n_in.outputs['Hold Frames'], n_gt0.inputs[0])
    n_mixf = nodes.new("ShaderNodeMixRGB"); n_mixf.location=(-220,-140)
    links.new(n_gt0.outputs['Value'], n_mixf.inputs['Fac'])
    links.new(n_time.outputs['Frame'], n_mixf.inputs['Color1'])
    links.new(n_mulh.outputs['Value'], n_mixf.inputs['Color2'])

    n_mul_freq = nodes.new("ShaderNodeMath"); n_mul_freq.operation='MULTIPLY'; n_mul_freq.location = (-20,-140)
    links.new(n_mixf.outputs['Color'], n_mul_freq.inputs[0])
    links.new(n_in.outputs['Frequency'], n_mul_freq.inputs[1])

    def axis_phase(pos_out, y):
        add1 = nodes.new("ShaderNodeMath"); add1.operation='ADD'; add1.location=(160,y)
        links.new(n_mul_freq.outputs['Value'], add1.inputs[0]); links.new(n_in.outputs['Seed'], add1.inputs[1])
        add2 = nodes.new("ShaderNodeMath"); add2.operation='ADD'; add2.location=(320,y)
        links.new(add1.outputs['Value'], add2.inputs[0]); links.new(pos_out, add2.inputs[1])
        s = nodes.new("ShaderNodeMath"); s.operation='SINE'; s.location=(500,y)
        links.new(add2.outputs['Value'], s.inputs[0])
        pack = nodes.new("ShaderNodeCombineXYZ"); pack.location=(660,y)
        links.new(s.outputs['Value'], pack.inputs['X']); links.new(s.outputs['Value'], pack.inputs['Y']); links.new(s.outputs['Value'], pack.inputs['Z'])
        step = nodes.new("ShaderNodeCombineXYZ"); step.location=(660,y-120)
        step.inputs['X'].default_value = step.inputs['Y'].default_value = step.inputs['Z'].default_value = 0.3
        mod = nodes.new("ShaderNodeVectorMath"); mod.operation='MODULO'; mod.location=(840,y)
        links.new(pack.outputs['Vector'], mod.inputs[0]); links.new(step.outputs['Vector'], mod.inputs[1])
        sub = nodes.new("ShaderNodeVectorMath"); sub.operation='SUBTRACT'; sub.location=(1000,y)
        sub.inputs[1].default_value = (0.15,0.15,0.15)
        links.new(mod.outputs['Vector'], sub.inputs[0])
        sep2 = nodes.new("ShaderNodeSeparateXYZ"); sep2.location=(1160,y)
        links.new(sub.outputs['Vector'], sep2.inputs['Vector'])
        return sep2.outputs['X']

    dx = axis_phase(n_sep.outputs['X'], 140)
    dy = axis_phase(n_sep.outputs['Y'], 60)
    dz = axis_phase(n_sep.outputs['Z'], -20)

    comb_disp = nodes.new("ShaderNodeCombineXYZ"); comb_disp.location=(1280, 80)
    links.new(dx, comb_disp.inputs['X']); links.new(dy, comb_disp.inputs['Y']); links.new(dz, comb_disp.inputs['Z'])

    v_z = nodes.new("ShaderNodeCombineXYZ"); v_z.location=(1280,-60); v_z.inputs['X'].default_value = v_z.inputs['Y'].default_value = 0.0
    links.new(n_in.outputs['Amplitude Global'], v_z.inputs['Z'])
    v_xyz = nodes.new("ShaderNodeCombineXYZ"); v_xyz.location=(1280,-140)
    links.new(n_in.outputs['Amplitude Global'], v_xyz.inputs['X']); links.new(n_in.outputs['Amplitude Global'], v_xyz.inputs['Y']); links.new(n_in.outputs['Amplitude Global'], v_xyz.inputs['Z'])
    v_custom = nodes.new("ShaderNodeCombineXYZ"); v_custom.location=(1280,-220)
    links.new(n_in.outputs['Amp X'], v_custom.inputs['X']); links.new(n_in.outputs['Amp Y'], v_custom.inputs['Y']); links.new(n_in.outputs['Amp Z'], v_custom.inputs['Z'])

    eq_xyz = nodes.new("ShaderNodeMath"); eq_xyz.operation='COMPARE'; eq_xyz.inputs[1].default_value = 1.0; eq_xyz.inputs[2].default_value = 0.001; eq_xyz.location=(1460,-60)
    eq_custom = nodes.new("ShaderNodeMath"); eq_custom.operation='COMPARE'; eq_custom.inputs[1].default_value = 2.0; eq_custom.inputs[2].default_value = 0.001; eq_custom.location=(1460,-140)
    links.new(n_in.outputs['Axes Mode (0=Z,1=XYZ,2=Custom)'], eq_xyz.inputs[0]); links.new(n_in.outputs['Axes Mode (0=Z,1=XYZ,2=Custom)'], eq_custom.inputs[0])

    mix_z_xyz = nodes.new("ShaderNodeMixRGB"); mix_z_xyz.location=(1640,-60)
    links.new(eq_xyz.outputs['Value'], mix_z_xyz.inputs['Fac']); links.new(v_z.outputs['Vector'], mix_z_xyz.inputs['Color1']); links.new(v_xyz.outputs['Vector'], mix_z_xyz.inputs['Color2'])

    mix_amp = nodes.new("ShaderNodeMixRGB"); mix_amp.location=(1800,-60)
    links.new(eq_custom.outputs['Value'], mix_amp.inputs['Fac']); links.new(mix_z_xyz.outputs['Color'], mix_amp.inputs['Color1']); links.new(v_custom.outputs['Vector'], mix_amp.inputs['Color2'])

    mul_disp = nodes.new("ShaderNodeVectorMath"); mul_disp.operation='MULTIPLY'; mul_disp.location=(1460, 80)
    links.new(comb_disp.outputs['Vector'], mul_disp.inputs[0]); links.new(mix_amp.outputs['Color'], mul_disp.inputs[1])

    setpos = nodes.new("GeometryNodeSetPosition"); setpos.location=(1600, 0)
    links.new(n_in.outputs['Geometry'], setpos.inputs['Geometry']); links.new(mul_disp.outputs['Vector'], setpos.inputs['Offset'])
    links.new(setpos.outputs['Geometry'], n_out.inputs['Geometry'])
    return ng


# ----------------------- Helper: inputs & sync -----------------------
def non_geo_inputs_of_group(ng):
    try:
        src = [item for item in ng.interface.items_tree if getattr(item, "in_out", "") == 'INPUT']
    except Exception:
        src = list(getattr(ng.interface, "inputs", []))
    out = [s for s in src if getattr(s, "socket_type", "") != 'NodeSocketGeometry' and s.name != "Geometry"]
    return out

def force_reattach(mod, ng):
    """Force Blender to re-instantiate modifier inputs to reflect new defaults immediately."""
    mod.node_group = None
    try: bpy.context.view_layer.update()
    except: pass
    mod.node_group = ng
    try: bpy.context.view_layer.update()
    except: pass

def set_modifier_and_defaults(mod, values_by_name):
    # Set group defaults first
    for s in non_geo_inputs_of_group(mod.node_group):
        if hasattr(s, "default_value") and s.name in values_by_name:
            try: s.default_value = float(values_by_name[s.name])
            except: pass
    # Reattach so defaults reflow into modifier
    force_reattach(mod, mod.node_group)
    # Now set idprops by index (Input_2..), so they override defaults
    inputs = non_geo_inputs_of_group(mod.node_group)
    for i, s in enumerate(inputs, start=2):
        key = f"Input_{i}"
        if s.name in values_by_name:
            try: mod[key] = float(values_by_name[s.name])
            except Exception:
                try:
                    mod.id_properties_ui(key)
                    mod[key] = float(values_by_name[s.name])
                except: pass


# ----------------------- Modifier -----------------------
def add_or_update_modifier(obj, s):
    if not obj or obj.type != 'MESH': return None
    ng = ensure_gn_group()
    mod = obj.modifiers.get(MOD_NAME) or obj.modifiers.new(MOD_NAME, 'NODES')
    if mod.node_group != ng:
        mod.node_group = ng
    axes_mode = 0.0 if s.psxpro_axes=='Z' else (1.0 if s.psxpro_axes=='XYZ' else 2.0)
    vals = {
        "Frequency": s.psxpro_freq,
        "Amplitude Global": s.psxpro_gamp,
        "Amp X": s.psxpro_ampx,
        "Amp Y": s.psxpro_ampy,
        "Amp Z": s.psxpro_ampz,
        "Axes Mode (0=Z,1=XYZ,2=Custom)": axes_mode,
        "Hold Frames": s.psxpro_hold,
        "Seed": s.psxpro_seed,
    }
    set_modifier_and_defaults(mod, vals)
    try: bpy.context.view_layer.update()
    except: pass
    return mod

def remove_modifier(obj):
    m = obj.modifiers.get(MOD_NAME)
    if m: obj.modifiers.remove(m)


# ----------------------- Presets -----------------------
def preset_dir():
    root = bpy.utils.user_resource('SCRIPTS', path="presets", create=True)
    p = Path(root) / "psx_wobble_pro"
    p.mkdir(parents=True, exist_ok=True)
    return p

def ensure_default_preset():
    p = preset_dir() / "default.json"
    if not p.exists():
        data = dict(freq=6.2, gamp=0.07, ampx=0.0, ampy=0.0, ampz=0.07, axes='Z', hold=0, seed=1.0)
        p.write_text(json.dumps(data, indent=2), encoding="utf-8")

def build_enum_items():
    ensure_default_preset()
    names = sorted([f.stem for f in preset_dir().glob("*.json")])
    if not names:
        names = ["default"]
    return [(n, n, "", i) for i, n in enumerate(names)]

def rebuild_preset_enum():
    items = build_enum_items()
    default = "default" if any(i[0]=="default" for i in items) else items[0][0]
    bpy.types.Scene.psxpro_preset = bpy.props.EnumProperty(name="Preset", items=items, default=default)

def save_preset(name, s):
    name = (name or "default").strip()
    data = dict(
        freq = s.psxpro_freq,
        gamp = s.psxpro_gamp,
        ampx = s.psxpro_ampx,
        ampy = s.psxpro_ampy,
        ampz = s.psxpro_ampz,
        axes = s.psxpro_axes,
        hold = s.psxpro_hold,
        seed = s.psxpro_seed,
    )
    out = preset_dir() / f"{name}.json"
    out.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return str(out)

def load_preset_to_scene(name, s):
    fp = preset_dir() / f"{name}.json"
    if not fp.exists(): return False
    try:
        data = json.loads(fp.read_text(encoding="utf-8"))
        s.psxpro_freq = float(data.get("freq", s.psxpro_freq))
        s.psxpro_gamp = float(data.get("gamp", s.psxpro_gamp))
        s.psxpro_ampx = float(data.get("ampx", s.psxpro_ampx))
        s.psxpro_ampy = float(data.get("ampy", s.psxpro_ampy))
        s.psxpro_ampz = float(data.get("ampz", s.psxpro_ampz))
        s.psxpro_axes = data.get("axes", s.psxpro_axes)
        s.psxpro_hold = int(data.get("hold", s.psxpro_hold))
        s.psxpro_seed = float(data.get("seed", s.psxpro_seed))
        return True
    except Exception as e:
        print("Preset load error:", e)
        return False


# ----------------------- Operators -----------------------
class PSXPRO_OT_Add(bpy.types.Operator):
    bl_idname = "psx_wobble_pro.add"
    bl_label = "Add / Update"
    bl_options = {'REGISTER','UNDO'}
    def execute(self, ctx):
        mod = add_or_update_modifier(ctx.active_object, ctx.scene)
        if not mod:
            self.report({'ERROR'}, "Select a mesh object")
            return {'CANCELLED'}
        self.report({'INFO'}, "Synced to modifier")
        return {'FINISHED'}

class PSXPRO_OT_Remove(bpy.types.Operator):
    bl_idname = "psx_wobble_pro.remove"
    bl_label = "Remove"
    bl_options = {'REGISTER','UNDO'}
    def execute(self, ctx):
        remove_modifier(ctx.active_object)
        return {'FINISHED'}

class PSXPRO_OT_SavePreset(bpy.types.Operator):
    bl_idname = "psx_wobble_pro.save_preset"
    bl_label = "Save Preset"
    name: bpy.props.StringProperty(name="Preset Name", default="default")
    def invoke(self, ctx, event):
        return ctx.window_manager.invoke_props_dialog(self)
    def draw(self, ctx):
        self.layout.prop(self, "name")
    def execute(self, ctx):
        path = save_preset(self.name, ctx.scene)
        rebuild_preset_enum()
        ctx.scene.psxpro_preset = self.name
        self.report({'INFO'}, f"Saved: {path}")
        return {'FINISHED'}

class PSXPRO_OT_ApplyPreset(bpy.types.Operator):
    bl_idname = "psx_wobble_pro.apply_preset"
    bl_label = "Apply Preset"
    bl_description = "Load selected preset into UI and sync to modifier"
    def execute(self, ctx):
        name = getattr(ctx.scene, "psxpro_preset", "default")
        ok = load_preset_to_scene(name, ctx.scene)
        if ok and ctx.active_object:
            add_or_update_modifier(ctx.active_object, ctx.scene)
            self.report({'INFO'}, f"Applied preset: {name}")
            return {'FINISHED'}
        self.report({'ERROR'}, "Failed to apply preset")
        return {'CANCELLED'}




def register():
    try:
        bpy.utils.register_class(LowPolyHelperOperator)
        bpy.utils.register_class(PSXTextureGeneratorOperator)
        bpy.utils.register_class(PSXTextureBakeOperator)
        bpy.utils.register_class(PSXTextureDitherOperator)
        bpy.utils.register_class(PSXTextureUndoDitherOperator)
        bpy.utils.register_class(PSXVertexWobbleOperator)
        bpy.utils.register_class(PSXVertexWobbleRemoveOperator)
        bpy.utils.register_class(PSXPRO_OT_Add)
        bpy.utils.register_class(PSXPRO_OT_Remove)
        bpy.utils.register_class(PSXPRO_OT_SavePreset)
        bpy.utils.register_class(PSXPRO_OT_ApplyPreset)
        bpy.utils.register_class(PSXRenderSettingsOperator)
        bpy.utils.register_class(PSXRetroPanel)

        bpy.types.Scene.low_poly_ratio = bpy.props.FloatProperty(
            name="Decimate Ratio",
            description="Percentage of polygons to keep",
            min=0.1, max=0.9, default=0.3, step=1, precision=2
        )

        bpy.types.Scene.psx_texture_size = bpy.props.EnumProperty(
            name="Texture Size",
            description="Resolution of the generated texture",
            items=[
                ('64', "64x64", "Low resolution texture"),
                ('128', "128x128", "Medium resolution texture"),
                ('256', "256x256", "High resolution texture"),
            ],
            default='64'
        )

        bpy.types.Scene.psx_palette_size = bpy.props.IntProperty(
            name="Palette Size",
            description="Number of colors in the texture palette",
            min=8, max=256, default=16, step=1
        )

        bpy.types.Scene.psx_texture_pattern = bpy.props.EnumProperty(
            name="Texture Pattern",
            description="Pattern for generated texture",
            items=[
                ('CHECKER', "Checkerboard", "Black and white checkerboard pattern"),
                ('GRADIENT', "Random Gradient", "Random gradient pattern"),
            ],
            default='CHECKER'
        )

        bpy.types.Scene.psx_dither_method = bpy.props.EnumProperty(
            name="Dither Method",
            description="Dithering algorithm to apply",
            items=[
                ('BAYER', "Bayer 4x4 (fast)", "Ordered dithering with a 4x4 Bayer matrix, fast and retro-styled"),
                ('FLOYD_STEINBERG', "Floyd-Steinberg (slow)", "Classic error diffusion with 4 neighbors"),
                ('JJN', "Jarvis, Judice, Ninke (slow)", "Smoother dithering with 12 neighbors"),
                ('STUCKI', "Stucki (slow)", "Optimized version of JJN, slightly faster"),
                ('BURKES', "Burkes (slow)", "Simplified Stucki, faster but less clean"),
                ('SIERRA', "Sierra (slow)", "Faster variant of JJN"),
                ('SIERRA_TWO_ROW', "Sierra Two-Row (slow)", "Simplified Sierra, faster"),
                ('SIERRA_LITE', "Sierra Lite (slow)", "Minimalist Floyd-Steinberg derivative"),
                ('ATKINSON', "Atkinson (slow)", "Retro-style dithering with 75% error propagation"),
            ],
            default='BAYER'
        )

        bpy.types.Scene.psx_dither_palette_size = bpy.props.IntProperty(
            name="Dither Palette Size",
            description="Number of colors in the dithered texture palette",
            min=2, max=256, default=16, step=1
        )

        bpy.types.Scene.psx_dither_scale = bpy.props.FloatProperty(
            name="Dither Scale",
            description="Scale of the dithering effect (higher values make patterns coarser)",
            min=0.1, max=2.0, default=0.1, step=1
        )

        bpy.types.Scene.psx_wobble_amplitude = bpy.props.FloatProperty(
            name="Wobble Amplitude",
            description="Amplitude of vertex wobble (in Blender units)",
            min=0.0, max=0.2, default=0.07, step=1, precision=3
        )

        bpy.types.Scene.psx_wobble_frequency = bpy.props.FloatProperty(
            name="Wobble Frequency",
            description="Frequency of wobble (controls speed of jitter)",
            min=0.1, max=10.0, default=6.2, step=1, precision=2
        )

        bpy.types.Scene.psx_wobble_axes = bpy.props.EnumProperty(
            name="Wobble Axes",
            description="Axes along which to apply the wobble effect",
            items=[
                ('Z', "Z Only", "Apply wobble only along the Z axis"),
                ('XYZ', "All Axes", "Apply wobble along X, Y, and Z axes"),
            ],
            default='Z'
        )

        bpy.types.Scene.psx_render_resolution = bpy.props.EnumProperty(
            name="Render Resolution",
            description="Resolution for PSX-style rendering",
            items=[
                ('128x128', "128x128 [1:1]", "Square low resolution"),
                ('256x256', "256x256 [1:1]", "Square medium resolution"),
                ('512x512', "512x512 [1:1]", "Square high resolution"),
                ('320x240', "320x240 [4:3]", "Classic 4:3 low resolution"),
                ('640x480', "640x480 [4:3]", "Classic 4:3 medium resolution"),
                ('800x600', "800x600 [4:3]", "Classic 4:3 high resolution"),
                ('240x320', "240x320 [3:4]", "Portrait 3:4 low resolution"),
                ('480x640', "480x640 [3:4]", "Portrait 3:4 medium resolution"),
                ('360x640', "360x640 [9:16]", "Portrait 9:16 medium resolution"),
            ],
            default='320x240'
        )

        bpy.types.Scene.psx_lowres_shadows = bpy.props.BoolProperty(
            name="Low Resolution Shadows",
            description="Force pixelated low-resolution shadows for all lights",
            default=False
        )

        bpy.types.Scene.psx_disable_all_shadows = bpy.props.BoolProperty(
            name="Disable all shadows",
            description="Completely disable shadows for all lights",
            default=False
        )

        bpy.types.Scene.psx_disable_denoising = bpy.props.BoolProperty(
            name="Disable Denoising",
            description="Disable denoising for Cycles and EEVEE",
            default=True
        )

        bpy.types.Scene.psx_color_depth = bpy.props.EnumProperty(
            name="Color Depth",
            description="Color depth for PSX-style rendering",
            items=[('NONE', "None", "No color quantization in compositor"),
                
                ('16BIT', "16-bit", "65,536 colors"),
                ('8BIT', "8-bit", "256 colors"),
                ('5BIT', "5-bit", "32 colors per channel (PSX-style)"),
            ],
            default='NONE'
        )

        bpy.types.Scene.psx_use_low_filter_size = bpy.props.BoolProperty(
            name="Low Filter Size",
            description="Set Film Filter Size to 0.01 for pixelated PSX-style effect",
            default=True
        )
        # UI foldouts
        bpy.types.Scene.psx_ui_lowpoly = bpy.props.BoolProperty(
            name="Low poly helper (foldout)", default=True)
        bpy.types.Scene.psx_ui_texgen = bpy.props.BoolProperty(
            name="PSX Texture generator (foldout)", default=True)
        bpy.types.Scene.psx_ui_wobble = bpy.props.BoolProperty(
            name="Vertex Wobble Effect (foldout)", default=True)
        bpy.types.Scene.psx_ui_wobble_pro = bpy.props.BoolProperty(
            name="Vertex Wobble Pro (foldout)", default=True)
        bpy.types.Scene.psx_ui_render = bpy.props.BoolProperty(
            name="PSX Render Settings (foldout)", default=True)

        # PRO wobble props
        bpy.types.Scene.psxpro_freq = bpy.props.FloatProperty(name="Frequency", default=6.2, min=0.0, soft_max=20.0)
        bpy.types.Scene.psxpro_hold = bpy.props.IntProperty(name="Hold", default=0, min=0, max=100)
        bpy.types.Scene.psxpro_seed = bpy.props.FloatProperty(name="Seed", default=1.0, min=-1e6, max=1e6)
        bpy.types.Scene.psxpro_axes = bpy.props.EnumProperty(name="Axes", items=[('Z','Z',''),('XYZ','XYZ',''),('CUSTOM','Custom','')], default='Z')
        bpy.types.Scene.psxpro_gamp = bpy.props.FloatProperty(name="Global Amp", default=0.07, min=0.0, soft_max=0.3, precision=3)
        bpy.types.Scene.psxpro_ampx = bpy.props.FloatProperty(name="Amp X", default=0.0, min=0.0, soft_max=0.3, precision=3)
        bpy.types.Scene.psxpro_ampy = bpy.props.FloatProperty(name="Amp Y", default=0.0, min=0.0, soft_max=0.3, precision=3)
        bpy.types.Scene.psxpro_ampz = bpy.props.FloatProperty(name="Amp Z", default=0.07, min=0.0, soft_max=0.3, precision=3)

        rebuild_preset_enum()
            

    except Exception as e:
        print(f"Failed to register addon: {str(e)}")
    bpy.utils.register_class(PSX_OT_FixTextures)
    bpy.utils.register_class(PSX_PT_Tools)

def unregister():
    try:
        bpy.utils.unregister_class(LowPolyHelperOperator)
        bpy.utils.unregister_class(PSXTextureGeneratorOperator)
        bpy.utils.unregister_class(PSXTextureBakeOperator)
        bpy.utils.unregister_class(PSXTextureDitherOperator)
        bpy.utils.unregister_class(PSXTextureUndoDitherOperator)
        bpy.utils.unregister_class(PSXVertexWobbleOperator)
        bpy.utils.unregister_class(PSXVertexWobbleRemoveOperator)
        bpy.utils.unregister_class(PSXPRO_OT_Add)
        bpy.utils.unregister_class(PSXPRO_OT_Remove)
        bpy.utils.unregister_class(PSXPRO_OT_SavePreset)
        bpy.utils.unregister_class(PSXPRO_OT_ApplyPreset)
        bpy.utils.unregister_class(PSXRenderSettingsOperator)
        bpy.utils.unregister_class(PSXRetroPanel)
        del bpy.types.Scene.low_poly_ratio
        del bpy.types.Scene.psx_texture_size
        del bpy.types.Scene.psx_palette_size
        del bpy.types.Scene.psx_texture_pattern
        del bpy.types.Scene.psx_dither_method
        del bpy.types.Scene.psx_dither_palette_size
        del bpy.types.Scene.psx_dither_scale
        del bpy.types.Scene.psx_wobble_amplitude
        del bpy.types.Scene.psx_wobble_frequency
        del bpy.types.Scene.psx_wobble_axes
        del bpy.types.Scene.psx_render_resolution
        del bpy.types.Scene.psx_lowres_shadows
        del bpy.types.Scene.psx_disable_all_shadows
        del bpy.types.Scene.psx_disable_denoising
        del bpy.types.Scene.psx_color_depth
        del bpy.types.Scene.psx_use_low_filter_size
        del bpy.types.Scene.psx_ui_lowpoly
        del bpy.types.Scene.psx_ui_texgen
        del bpy.types.Scene.psx_ui_wobble
        del bpy.types.Scene.psx_ui_wobble_pro
        del bpy.types.Scene.psxpro_freq
        del bpy.types.Scene.psxpro_hold
        del bpy.types.Scene.psxpro_seed
        del bpy.types.Scene.psxpro_axes
        del bpy.types.Scene.psxpro_gamp
        del bpy.types.Scene.psxpro_ampx
        del bpy.types.Scene.psxpro_ampy
        del bpy.types.Scene.psxpro_ampz
        del bpy.types.Scene.psxpro_preset
        del bpy.types.Scene.psx_ui_render
    except Exception as e:
        print(f"Failed to unregister addon: {str(e)}")
    bpy.utils.unregister_class(PSX_PT_Tools)
    bpy.utils.unregister_class(PSX_OT_FixTextures)