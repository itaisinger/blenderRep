# SPDX-License-Identifier: MIT
# -*- coding: utf-8 -*-
"""
PSX Retro Tools package entry.
This file wires the core (psx_addon.py) and the Vertex Snapping module (vertex_snapping.py).
"""
bl_info = {
    "name": "PSX Retro Tools",
    "author": "Igor Shevchenko (https://x.com/cryptofawkek)",
    "version": (1, 0, 0),
    "blender": (4, 3, 0),
    "location": "View3D > Sidebar > PSX Retro",
    "description": "Tools for creating PSX-style retro graphics, plus Vertex Screen Snapping.",
    "doc_url": "https://x.com/cryptofawkek",
    "category": "3D View"
}

from importlib import import_module

_core = None
_vsn = None

def register():
    global _core, _vsn
    # Core
    _core = import_module(".psx_addon", package=__name__)
    if hasattr(_core, "register"):
        _core.register()
    # Vertex Snapping
    try:
        _vsn = import_module(".vertex_snapping", package=__name__)
        if hasattr(_vsn, "register"):
            _vsn.register()
    except Exception as e:
        print("[PSX] Vertex Snapping failed to load:", e)

def unregister():
    global _core, _vsn
    # Vertex Snapping first
    try:
        if _vsn and hasattr(_vsn, "unregister"):
            _vsn.unregister()
    except Exception as e:
        print("[PSX] Vertex Snapping failed to unregister:", e)
    # Core
    if _core and hasattr(_core, "unregister"):
        _core.unregister()
