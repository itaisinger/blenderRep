  _____   _______   __  _____  ______ _______ _____   ____    _______ ____   ____  _       _____ 
 |  __ \ / ____\ \ / / |  __ \|  ____|__   __|  __ \ / __ \  |__   __/ __ \ / __ \| |     / ____|
 | |__) | (___  \ V /  | |__) | |__     | |  | |__) | |  | |    | | | |  | | |  | | |    | (___  
 |  ___/ \___ \  > <   |  _  /|  __|    | |  |  _  /| |  | |    | | | |  | | |  | | |     \___ \ 
 | |     ____) |/ . \  | | \ \| |____   | |  | | \ \| |__| |    | | | |__| | |__| | |____ ____) |
 |_|    |_____//_/ \_\ |_|  \_\______|  |_|  |_|  \_\\____/     |_|  \____/ \____/|______|_____/ 


PSX Retro Tools for Blender

Create low-res, low-poly, PS1-style graphics — effortlessly.
Tools for texture baking, vertex wobble, dithering, and render setup — all in one panel.

Features:
---------
- Low-Poly Simplifier — Automatically decimate and triangulate meshes for authentic PSX aesthetics.
- Low-Resolution Texture Baking — Bake all object materials into a single low-res texture, preserving UV layout and palette.
- Texture Generator — Generate base textures (checkerboard, gradients) with limited color palettes.
- Color Dithering — Bayer, Floyd–Steinberg, Atkinson, and more, with adjustable scale.
- Vertex Wobble (Classic) — Geometry Nodes–based vertex jitter effect in the style of PS1.
- Vertex Wobble PRO — Advanced version, hold frames, axis selection, per-axis amplitude, presets, and instant modifier sync.
- Shadow Controls — Low Resolution Shadows mode and full shadow disabling.
- Render Presets — Quick PSX resolution presets, color depth options, AA toggle, and shadow toggle.

Compatibility:
--------------
- Blender 4.3+
- Tested on Windows & macOS
- Requires: Pillow, NumPy

Install:
--------
1. Download psx_addon.zip
2. In Blender: Edit > Preferences > Add-ons > Install
3. Enable 'PSX Retro Tools' from the list

Tips & Notes:
-------------
- After generating a texture, you can enhance it in Texture Paint and then apply dithering for a stylized look.
- Baking works correctly only with a single texture atlas.
- If the object uses multiple materials or images, the result may be incorrect.
- The texture size selected in the generator also determines the baked texture size.

Roadmap:
--------
- True screen-space vertex displacement — Full implementation of per-vertex displacement in actual screen coordinates for authentic PSX wobble on animated objects.
- Texture preview directly in the add-on panel.
- Export baked textures to PNG in one click.

Author:
-------
Created by @cryptofawkek (https://x.com/cryptofawkek)
​Credits: Vertex Screen Snapping nodes — Duality  
Feedback & bug reports welcome — DM or Telegram: @fawkes
