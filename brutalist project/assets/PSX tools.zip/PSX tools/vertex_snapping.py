# SPDX-License-Identifier: MIT
# -*- coding: utf-8 -*-
import os
import bpy
from bpy.types import Operator, Panel, PropertyGroup
from bpy.props import PointerProperty, FloatProperty, StringProperty

# Names
MOD_NAME = "Vertex Snapping"          # modifier name (no "tester")
NODEGROUP_NAME = "Vertex Snapping"    # node group name inside vertex_snapping.blend

# ---------- helpers ----------

def _addon_dir() -> str:
    try:
        return os.path.dirname(os.path.realpath(__file__))
    except Exception:
        return os.path.dirname(__file__)

def _default_blend_path() -> str:
    # vertex_snapping.blend must lie next to this module
    return os.path.join(_addon_dir(), "vertex_snapping.blend")

def _get_nodegroup():
    return bpy.data.node_groups.get(NODEGROUP_NAME)

def _target_obj(context):
    obj = context.active_object or context.object
    return obj if (obj and obj.type in {'MESH','CURVE','SURFACE','META'}) else None

def _append_group_from_blend(op_report=None):
    """Append NODEGROUP_NAME from vertex_snapping.blend next to this file."""
    if _get_nodegroup():
        if op_report: op_report({'INFO'}, f"'{NODEGROUP_NAME}' already loaded.")
        return True

    path = _default_blend_path()
    if not os.path.exists(path):
        if op_report: op_report({'ERROR'}, f"vertex_snapping.blend not found:\n{path}")
        return False

    try:
        with bpy.data.libraries.load(path, link=False) as (data_from, data_to):
            if NODEGROUP_NAME not in data_from.node_groups:
                if op_report: op_report({'ERROR'}, f"'{NODEGROUP_NAME}' not in file: {os.path.basename(path)}")
                return False
            data_to.node_groups = [NODEGROUP_NAME]
    except Exception as e:
        if op_report: op_report({'ERROR'}, f"Append failed: {e}")
        return False

    if op_report: op_report({'INFO'}, f"Loaded '{NODEGROUP_NAME}' from '{os.path.basename(path)}'.")
    return True

def _set_inputs(gn_mod: bpy.types.NodesModifier, *, camera_obj, size_value: float):
    """Set GN inputs by interface identifiers; fallback to legacy names."""
    ng = gn_mod.node_group
    ok_ref = ok_size = False

    try:
        items = list(ng.interface.items_tree)
    except Exception:
        items = []
    inputs = [it for it in items if getattr(it, "item_type", "") == 'SOCKET' and getattr(it, "in_out", "") == 'INPUT']

    ref_ident = size_ident = None
    for it in inputs:
        nm = (getattr(it, "name", "") or "").lower()
        ident = getattr(it, "identifier", None)
        if "reference" in nm and "object" in nm:
            ref_ident = ident
        if "size" in nm:
            size_ident = ident

    def try_set(key, value):
        if not key:
            return False
        try:
            gn_mod[key] = value
            return True
        except Exception:
            return False

    if camera_obj:
        ok_ref = try_set(ref_ident, camera_obj)
    ok_size = try_set(size_ident, float(size_value))

    if camera_obj and not ok_ref:
        for k in ("Reference Object", "Input_2", "Socket_2", "Socket_001"):
            try:
                gn_mod[k] = camera_obj
                ok_ref = True
                break
            except Exception:
                pass

    if not ok_size:
        for k in ("Size", "Input_3", "Socket_3", "Socket_002"):
            try:
                gn_mod[k] = float(size_value)
                ok_size = True
                break
            except Exception:
                pass

    return ok_ref, ok_size

# ---------- props ----------

class VSN_Props(PropertyGroup):
    camera: PointerProperty(
        name="Camera",
        type=bpy.types.Object,
        description="Reference camera (screen space)",
        poll=lambda self, obj: (obj and obj.type == 'CAMERA')
    )
    size: FloatProperty(
        name="Size",
        description="Grid size in camera space",
        default=0.5, min=0.0, soft_max=10.0
    )
    status: StringProperty(default="")

# ---------- operators ----------

class VSN_OT_Append(Operator):
    """Load node group from vertex_snapping.blend next to the add-on"""
    bl_idname = "vsn.append_from_addon"
    bl_label = "Press to load nodes from .blend"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        ok = _append_group_from_blend(self.report)
        return {'FINISHED'} if ok else {'CANCELLED'}

class VSN_OT_Apply(Operator):
    bl_idname = "vsn.apply"
    bl_label = "Apply Vertex Snapping Effect"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.vsn_props
        obj = _target_obj(context)
        if not obj:
            self.report({'ERROR'}, "Select a mesh/curve/surface object.")
            return {'CANCELLED'}

        # Ensure nodes loaded (user may skip the first button)
        if not _append_group_from_blend(self.report):
            return {'CANCELLED'}

        ng = _get_nodegroup()
        if not ng:
            self.report({'ERROR'}, f"Node group '{NODEGROUP_NAME}' not available.")
            return {'CANCELLED'}

        mod = obj.modifiers.get(MOD_NAME)
        if mod and mod.type != 'NODES':
            obj.modifiers.remove(mod); mod = None
        if not mod:
            mod = obj.modifiers.new(MOD_NAME, 'NODES')
        mod.node_group = ng

        cam = props.camera or context.scene.camera
        ok_ref, ok_size = _set_inputs(mod, camera_obj=cam, size_value=props.size)
        props.status = f"Applied | camera={'OK' if ok_ref else 'select'} | size={'OK' if ok_size else '?'}"
        self.report({'INFO'}, props.status)
        return {'FINISHED'}

class VSN_OT_Remove(Operator):
    bl_idname = "vsn.remove"
    bl_label = "Remove Vertex Snapping Effect"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = _target_obj(context)
        if not obj:
            self.report({'ERROR'}, "Select an object.")
            return {'CANCELLED'}
        mod = obj.modifiers.get(MOD_NAME)
        if mod:
            obj.modifiers.remove(mod)
            context.scene.vsn_props.status = "Removed"
            self.report({'INFO'}, "Modifier removed.")
        else:
            self.report({'INFO'}, "No vertex snapping modifier found.")
        return {'FINISHED'}

# ---------- UI ----------

class VSN_PT_Panel(Panel):
    bl_label = "Vertex Screen Snapping"
    bl_idname = "VSN_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'PSX Retro'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        p = context.scene.vsn_props

        box = layout.box()
        box.label(text="1) Load Node Group")
        box.operator("vsn.append_from_addon", icon='APPEND_BLEND')
        box.label(text="   From vertex_snapping.blend in add-on folder")

        box2 = layout.box()
        row = box2.row(align=True)
        row.prop(p, "camera", text="Camera")
        box2.prop(p, "size", text="Size")

        row2 = box2.row(align=True)
        row2.operator("vsn.apply", icon='CHECKMARK')
        row2.operator("vsn.remove", icon='TRASH')

        if p.status:
            layout.label(text=p.status, icon='INFO')

# ---------- register ----------

_CLASSES = (
    VSN_Props,
    VSN_OT_Append,
    VSN_OT_Apply,
    VSN_OT_Remove,
    VSN_PT_Panel,
)

def register():
    for cls in _CLASSES:
        try:
            bpy.utils.register_class(cls)
        except Exception as e:
            print("Register error:", cls, e)
    try:
        bpy.types.Scene.vsn_props = PointerProperty(type=VSN_Props)
    except Exception as e:
        print("Props register error:", e)

def unregister():
    try:
        if hasattr(bpy.types.Scene, "vsn_props"):
            del bpy.types.Scene.vsn_props
    except Exception as e:
        print("Props unregister error:", e)
    for cls in reversed(_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception as e:
            print("Unregister error:", cls, e)
